// Data cache and API client for Imobisoft Search Management endpoints.

export function getBaseApiUrl() {
    try {
        const component = document.querySelector('imobisoft-search-workspace');
        if (component?.hasAttribute('data-api-url')) {
            return component.getAttribute('data-api-url').replace(/\/$/, '') + '/';
        }
        if (window.IMOBISOFT_SEARCH_CONFIG?.apiUrl) {
            return window.IMOBISOFT_SEARCH_CONFIG.apiUrl.replace(/\/$/, '') + '/';
        }
    } catch (e) {
        console.warn('Error determining API URL:', e);
    }
    return '/umbraco/management/api/v1/imobisoft-search/';
}

const PROFILES_TTL_MS = 30000;
const CATALOG_TTL_MS = 60000;
const SETTINGS_TTL_MS = 30000;

/** @type {Map<string, {at: number, ttl: number, promise: Promise<any>}>} */
const _entries = new Map();

function _read(key, ttl, producer) {
    const hit = _entries.get(key);
    if (hit && (performance.now() - hit.at) < hit.ttl) return hit.promise;

    const forget = () => {
        const current = _entries.get(key);
        if (current && current.promise === promise) _entries.delete(key);
    };

    const promise = producer().then(
        result => {
            if (!result || result.ok === false) forget();
            return result;
        },
        err => {
            forget();
            throw err;
        }
    );

    _entries.set(key, { at: performance.now(), ttl, promise });
    return promise;
}

async function _json(fetchFn, url, options = {}) {
    const response = await fetchFn(url, {
        headers: {
            'Accept': 'application/json',
            ...(options.headers || {})
        },
        ...options
    });

    let data = null;
    try {
        const text = await response.text();
        if (text && text.trim().length > 0) {
            data = JSON.parse(text);
        }
    } catch {
        data = null;
    }

    return { ok: response.ok, status: response.status, data };
}

// ----------------- PROFILES API -----------------

export function getProfiles(fetchFn, { force = false } = {}) {
    const url = `${getBaseApiUrl()}profile`;
    if (force) _entries.delete("profiles");
    return _read("profiles", PROFILES_TTL_MS, () => _json(fetchFn, url));
}

export function getProfile(fetchFn, key, { force = false } = {}) {
    const cacheKey = `profile:${String(key).toLowerCase()}`;
    const url = `${getBaseApiUrl()}profile/${encodeURIComponent(key)}`;
    if (force) _entries.delete(cacheKey);
    return _read(cacheKey, PROFILES_TTL_MS, () => _json(fetchFn, url));
}

export async function createProfile(fetchFn, profile) {
    const url = `${getBaseApiUrl()}profile`;
    const res = await _json(fetchFn, url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile)
    });
    invalidateProfiles();
    return res;
}

export async function updateProfile(fetchFn, key, profile) {
    const url = `${getBaseApiUrl()}profile/${encodeURIComponent(key)}`;
    const res = await _json(fetchFn, url, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile)
    });
    invalidateProfiles();
    return res;
}

export async function setDefaultProfile(fetchFn, key) {
    const url = `${getBaseApiUrl()}profile/${encodeURIComponent(key)}/default`;
    const res = await _json(fetchFn, url, { method: 'POST' });
    invalidateProfiles();
    return res;
}

export async function deleteProfile(fetchFn, key) {
    const url = `${getBaseApiUrl()}profile/${encodeURIComponent(key)}`;
    const res = await _json(fetchFn, url, { method: 'DELETE' });
    invalidateProfiles();
    return res;
}

export function invalidateProfiles() {
    for (const key of Array.from(_entries.keys())) {
        if (key === "profiles" || key.startsWith("profile:")) _entries.delete(key);
    }
}

// ----------------- CATALOG API -----------------

export function getCatalog(fetchFn, { force = false } = {}) {
    const url = `${getBaseApiUrl()}catalog`;
    if (force) _entries.delete("catalog");
    return _read("catalog", CATALOG_TTL_MS, () => _json(fetchFn, url));
}

export function getIndexes(fetchFn, includeFields = true, { force = false } = {}) {
    const cacheKey = `catalog:indexes:${includeFields}`;
    const url = `${getBaseApiUrl()}catalog/index?includeFields=${includeFields}`;
    if (force) _entries.delete(cacheKey);
    return _read(cacheKey, CATALOG_TTL_MS, () => _json(fetchFn, url));
}

export function getSearchableFields(fetchFn, indexName, { force = false } = {}) {
    const cacheKey = `catalog:fields:${indexName}`;
    const url = `${getBaseApiUrl()}catalog/index/${encodeURIComponent(indexName)}/searchable-field`;
    if (force) _entries.delete(cacheKey);
    return _read(cacheKey, CATALOG_TTL_MS, () => _json(fetchFn, url));
}

export function getContentTypes(fetchFn, { force = false } = {}) {
    const url = `${getBaseApiUrl()}catalog/content-type`;
    if (force) _entries.delete("catalog:content-type");
    return _read("catalog:content-type", CATALOG_TTL_MS, () => _json(fetchFn, url));
}

export function getMediaTypes(fetchFn, { force = false } = {}) {
    const url = `${getBaseApiUrl()}catalog/media-type`;
    if (force) _entries.delete("catalog:media-type");
    return _read("catalog:media-type", CATALOG_TTL_MS, () => _json(fetchFn, url));
}

export function getLanguages(fetchFn, { force = false } = {}) {
    const url = `${getBaseApiUrl()}catalog/language`;
    if (force) _entries.delete("catalog:language");
    return _read("catalog:language", CATALOG_TTL_MS, () => _json(fetchFn, url));
}

// Resolves one node key to its display name for chips and summaries. Results are cached per key
// for the session - names rarely change and the endpoint is cheap, but pickers can render many.
const _nodeNameCache = new Map();

export async function getNodeName(fetchFn, key) {
    if (_nodeNameCache.has(key)) {
        return { ok: true, status: 200, data: _nodeNameCache.get(key) };
    }

    const url = `${getBaseApiUrl()}catalog/node?key=${encodeURIComponent(key)}`;
    const res = await _json(fetchFn, url);

    if (res.ok && res.data?.name) {
        _nodeNameCache.set(key, res.data);
    }

    return res;
}

// ----------------- INSIGHTS API -----------------

export function getInsights(fetchFn, days = 30, take = 25, { force = false } = {}) {
    const cacheKey = `insights:${days}:${take}`;
    const url = `${getBaseApiUrl()}insights?days=${days}&take=${take}`;
    if (force) _entries.delete(cacheKey);
    return _read(cacheKey, 10000, () => _json(fetchFn, url));
}

export async function purgeInsights(fetchFn) {
    const url = `${getBaseApiUrl()}insights/purge`;
    const res = await _json(fetchFn, url, { method: 'POST' });
    for (const key of Array.from(_entries.keys())) {
        if (key.startsWith("insights:")) _entries.delete(key);
    }
    return res;
}

// ----------------- SETTINGS API -----------------

export function getSettings(fetchFn, { force = false } = {}) {
    const url = `${getBaseApiUrl()}settings`;
    if (force) _entries.delete("settings");
    return _read("settings", SETTINGS_TTL_MS, () => _json(fetchFn, url));
}

export async function updateSettings(fetchFn, settings) {
    const url = `${getBaseApiUrl()}settings`;
    const res = await _json(fetchFn, url, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
    });
    _entries.delete("settings");
    return res;
}

// ----------------- AI API -----------------

/**
 * Whether an AI key is stored (never the key itself), plus the providers the package can call.
 */
export function getAiSettings(fetchFn, { force = false } = {}) {
    const url = `${getBaseApiUrl()}ai`;
    if (force) _entries.delete("ai");
    return _read("ai", SETTINGS_TTL_MS, () => _json(fetchFn, url));
}

export async function saveAiKey(fetchFn, apiKey) {
    const res = await _json(fetchFn, `${getBaseApiUrl()}ai/key`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey })
    });
    _entries.delete("ai");
    return res;
}

export async function deleteAiKey(fetchFn) {
    const res = await _json(fetchFn, `${getBaseApiUrl()}ai/key`, { method: 'DELETE' });
    _entries.delete("ai");
    return res;
}

/** The models the stored key can run, straight from the provider, plus the one to use. */
export function getAiModels(fetchFn, profileAlias) {
    const query = profileAlias ? `?profileAlias=${encodeURIComponent(profileAlias)}` : '';
    return _json(fetchFn, `${getBaseApiUrl()}ai/models${query}`);
}

/** Runs one real request against the configured provider to prove the setup works. */
export function testAi(fetchFn, profileAlias) {
    const query = profileAlias ? `?profileAlias=${encodeURIComponent(profileAlias)}` : '';
    return _json(fetchFn, `${getBaseApiUrl()}ai/test${query}`, { method: 'POST' });
}

// ----------------- SEARCH BOX ICON API -----------------

/**
 * Uploads a search icon chosen from the editor's own machine and resolves with its URL.
 * No Content-Type header: the browser has to set the multipart boundary itself.
 */
export async function uploadSearchBoxIcon(fetchFn, file) {
    const body = new FormData();
    body.append('file', file, file.name);

    return _json(fetchFn, `${getBaseApiUrl()}search-box-icon`, { method: 'POST', body });
}

// ----------------- PREVIEW & AUTOCOMPLETE API -----------------

export async function previewSearch(fetchFn, request) {
    const url = `${getBaseApiUrl()}preview`;
    return _json(fetchFn, url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request)
    });
}

export async function getAutocomplete(fetchFn, term, profileAlias = "", take = 10) {
    let url = `${getBaseApiUrl()}autocomplete?term=${encodeURIComponent(term || '')}&take=${take}`;
    if (profileAlias) {
        url += `&profileAlias=${encodeURIComponent(profileAlias)}`;
    }
    return _json(fetchFn, url);
}
